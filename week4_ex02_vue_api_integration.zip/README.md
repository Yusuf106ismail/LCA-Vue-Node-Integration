# TechVibe

## Description
TechVibe is a dynamic web application built for marketing and inventory teams to seamlessly manage online product catalogues. It enables administrators to view, add, and remove products dynamically without needing to reload the web page. The project connects a reactive frontend interface directly to an Express backend API.

## Tech Stack
* **Node.js:** JavaScript runtime environment used to execute server-side code outside the browser.
* **Express:** Web application framework for Node.js used to build RESTful API endpoints and handle HTTP requests.
* **Vue 3:** Progressive front-end JavaScript framework used to build interactive and reactive user interfaces.
* **Vite:** Next-generation frontend tooling used to serve, build, and optimize the Vue single-page application.
* **Axios:** Promise-based HTTP client used to send asynchronous API requests between the frontend and backend.

## Prerequisites
Node.js installed, npm available in the terminal. A .env file in the server root is required (see Environment Variables section below).

## Environment Variables
```env
PORT=3000
git clone <your-repository-url>
cd week4_ex02_vue_api_integration/server
npm install
cat << 'EOF' > ~/week4_ex02_vue_api_integration/server/.env
PORT=3000
