const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

let products = [
  { id: 1, name: 'Wireless Headphones', price: 99.99, category: 'Electronics' },
  { id: 2, name: 'Ergonomic Chair', price: 199.99, category: 'Office' },
  { id: 3, name: 'Mechanical Keyboard', price: 89.99, category: 'Electronics' }
];

app.get('/products', (req, res) => {
  res.json(products);
});

app.post('/products', (req, res) => {
  const { name, price, category } = req.body;
  if (!name || !price) {
    return res.status(400).json({ error: 'Name and price are required' });
  }

  const newProduct = {
    id: Date.now(),
    name,
    price: parseFloat(price),
    category: category || 'General'
  };

  products.push(newProduct);
  res.status(201).json(products);
});

app.delete('/products/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  products = products.filter(p => p.id !== productId);
  res.json(products);
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
